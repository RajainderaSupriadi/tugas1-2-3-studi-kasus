'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Mahasiswa:
    def __init__(self, nama, nim, prodi, nilai):
        self.nama = nama
        self.nim = nim
        self.prodi = prodi
        self.nilai = nilai

def input_data_mahasiswa(mahasiswa_list):
    nama = input("Masukkan nama mahasiswa: ")
    nim = input("Masukkan NIM mahasiswa: ")
    prodi = input("Masukkan prodi mahasiswa: ")
    nilai = float(input("Masukkan nilai mahasiswa: "))
    
    mahasiswa = Mahasiswa(nama, nim, prodi, nilai)
    mahasiswa_list.append(mahasiswa)
    print("Data mahasiswa berhasil ditambahkan!\n")

def tampilkan_data_mahasiswa(mahasiswa_list):
    if not mahasiswa_list:
        print("Tidak ada data mahasiswa.")
        return
    print("\nData Mahasiswa:")
    for mahasiswa in mahasiswa_list:
        print(f"Nama: {mahasiswa.nama}, NIM: {mahasiswa.nim}, Prodi: {mahasiswa.prodi}, Nilai: {mahasiswa.nilai}")
    print()

def hitung_rata_rata_nilai(mahasiswa_list):
    if not mahasiswa_list:
        print("Tidak ada data mahasiswa.")
        return 0
    total_nilai = sum(mahasiswa.nilai for mahasiswa in mahasiswa_list)
    rata_rata = total_nilai / len(mahasiswa_list)
    print(f"Rata-rata nilai mahasiswa: {rata_rata}")
    return rata_rata

def cari_mahasiswa_tertinggi_terendah(mahasiswa_list):
    if not mahasiswa_list:
        print("Tidak ada data mahasiswa.")
        return
    tertinggi = max(mahasiswa_list, key=lambda m: m.nilai)
    terendah = min(mahasiswa_list, key=lambda m: m.nilai)
    print(f"Mahasiswa dengan nilai tertinggi: Nama: {tertinggi.nama}, NIM: {tertinggi.nim}, Prodi: {tertinggi.prodi}, Nilai: {tertinggi.nilai}")
    print(f"Mahasiswa dengan nilai terendah: Nama: {terendah.nama}, NIM: {terendah.nim}, Prodi: {terendah.prodi}, Nilai: {terendah.nilai}")

class Barang:
    def __init__(self, nama, kode, jumlah):
        self.nama = nama
        self.kode = kode
        self.jumlah = jumlah

def input_data(barang_list):
    nama = input("Masukkan nama barang: ")
    kode = input("Masukkan kode barang: ")
    jumlah = int(input("Masukkan jumlah barang: "))
    
    barang = Barang(nama, kode, jumlah)
    barang_list.append(barang)
    print("Barang berhasil ditambahkan!\n")

def tampilkan_data(barang_list):
    if not barang_list:
        print("Tidak ada data barang.")
        return
    print("\nData Barang:")
    for barang in barang_list:
        print(f"Nama: {barang.nama}, Kode: {barang.kode}, Jumlah: {barang.jumlah}")
    print()

def cari_barang(barang_list, kode):
    for barang in barang_list:
        if barang.kode == kode:
            print(f"Barang ditemukan: Nama: {barang.nama}, Kode: {barang.kode}, Jumlah: {barang.jumlah}")
            return barang
    print("Barang tidak ditemukan.")
    return None

def hapus_barang(barang_list, kode):
    barang = cari_barang(barang_list, kode)
    if barang:
        barang_list.remove(barang)
        print("Barang berhasil dihapus!\n")
    else:
        print("Barang dengan kode tersebut tidak ditemukan.\n")

class Transaksi:
    def __init__(self, jenis, jumlah, deskripsi):
        self.jenis = jenis  # 'pemasukan' atau 'pengeluaran'
        self.jumlah = jumlah
        self.deskripsi = deskripsi

def input_transaksi(transaksi_list):
    jenis = input("Masukkan jenis transaksi (pemasukan/pengeluaran): ").strip().lower()
    jumlah = float(input("Masukkan jumlah transaksi: "))
    deskripsi = input("Masukkan deskripsi transaksi: ")
    
    transaksi = Transaksi(jenis, jumlah, deskripsi)
    transaksi_list.append(transaksi)
    print("Transaksi berhasil ditambahkan!\n")

def tampilkan_transaksi(transaksi_list):
    if not transaksi_list:
        print("Tidak ada data transaksi.")
        return
    print("\nData Transaksi:")
    for transaksi in transaksi_list:
        print(f"Jenis: {transaksi.jenis.capitalize()}, Jumlah: {transaksi.jumlah}, Deskripsi: {transaksi.deskripsi}")
    print()

def hitung_total_pemasukan(transaksi_list):
    total = sum(transaksi.jumlah for transaksi in transaksi_list if transaksi.jenis == 'pemasukan')
    print(f"Total Pemasukan: {total}")
    return total

def hitung_total_pengeluaran(transaksi_list):
    total = sum(transaksi.jumlah for transaksi in transaksi_list if transaksi.jenis == 'pengeluaran')
    print(f"Total Pengeluaran: {total}")
    return total

def hitung_saldo_akhir(transaksi_list):
    total_pemasukan = hitung_total_pemasukan(transaksi_list)
    total_pengeluaran = hitung_total_pengeluaran(transaksi_list)
    saldo_akhir = total_pemasukan - total_pengeluaran
    print(f"Saldo Akhir: {saldo_akhir}")
    return saldo_akhir

def menu_mahasiswa(mahasiswa_list):
    while True:
        print("\nMenu Mahasiswa:")
        print("1. Tambah data mahasiswa")
        print("2. Tampilkan semua data mahasiswa")
        print("3. Hitung rata-rata nilai mahasiswa")
        print("4. Cari mahasiswa dengan nilai tertinggi dan terendah")
        print("5. Kembali ke menu utama")
        
        pilihan = input("Pilih opsi (1/2/3/4/5): ")
        
        if pilihan == '1':
            input_data_mahasiswa(mahasiswa_list)
        elif pilihan == '2':
            tampilkan_data_mahasiswa(mahasiswa_list)
        elif pilihan == '3':
            hitung_rata_rata_nilai(mahasiswa_list)
        elif pilihan == '4':
            cari_mahasiswa_tertinggi_terendah(mahasiswa_list)
        elif pilihan == '5':
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

def menu_barang(barang_list):
    while True:
        print("\nMenu Barang:")
        print("1. Tambah barang")
        print("2. Tampilkan semua barang")
        print("3. Cari barang berdasarkan kode")
        print("4. Hapus barang berdasarkan kode")
        print("5. Kembali ke menu utama")
        
        pilihan = input("Pilih opsi (1/2/3/4/5): ")
        
        if pilihan == '1':
            input_data(barang_list)
        elif pilihan == '2':
            tampilkan_data(barang_list)
        elif pilihan == '3':
            kode = input("Masukkan kode barang yang dicari: ")
            cari_barang(barang_list, kode)
        elif pilihan == '4':
            kode = input("Masukkan kode barang yang ingin dihapus: ")
            hapus_barang(barang_list, kode)
        elif pilihan == '5':
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

def menu_transaksi(transaksi_list):
    while True:
        print("\nMenu Transaksi:")
        print("1. Tambah transaksi")
        print("2. Tampilkan semua transaksi")
        print("3. Hitung total pemasukan")
        print("4. Hitung total pengeluaran")
        print("5. Hitung saldo akhir")
        print("6. Kembali ke menu utama")
        
        pilihan = input("Pilih opsi (1/2/3/4/5/6): ")
        
        if pilihan == '1':
            input_transaksi(transaksi_list)
        elif pilihan == '2':
            tampilkan_transaksi(transaksi_list)
        elif pilihan == '3':
            hitung_total_pemasukan(transaksi_list)
        elif pilihan == '4':
            hitung_total_pengeluaran(transaksi_list)
        elif pilihan == '5':
            hitung_saldo_akhir(transaksi_list)
        elif pilihan == '6':
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

def menu_utama():
    mahasiswa_list = []
    barang_list = []
    transaksi_list = []

    while True:
        print("\nMenu Utama:")
        print("1. Manajemen Data Mahasiswa")
        print("2. Inventaris Barang")
        print("3. Pengelolaan Keuangan Pribadi")
        print("4. Keluar")
        
        pilihan = input("Pilih opsi (1/2/3/4): ")
        
        if pilihan == '1':
            menu_mahasiswa(mahasiswa_list)
        elif pilihan == '2':
            menu_barang(barang_list)
        elif pilihan == '3':
            menu_transaksi(transaksi_list)
        elif pilihan == '4':
            print("Terima kasih telah menggunakan program ini.")
            break
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

# Menjalankan menu utama
menu_utama()
